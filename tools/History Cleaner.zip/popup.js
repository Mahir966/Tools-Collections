document.addEventListener('DOMContentLoaded', function() {
    const cleanBtn = document.getElementById('clearHistoryBtn');
    const statusEl = document.getElementById('status');
    const btnText = cleanBtn.querySelector('.btn-text');

    cleanBtn.addEventListener('click', function() {
        // ডিজেবল বাটন
        cleanBtn.disabled = true;
        btnText.innerHTML = '<span class="spinner"></span> Cleaning...';
        
        // স্ট্যাটাস দেখাও
        statusEl.textContent = 'Clearing history...';
        statusEl.classList.add('show');

        // মেসেজ পাঠাও
        chrome.runtime.sendMessage({action: "clear"}, function(response) {
            if (response && response.status === "success") {
                // সাকসেস
                statusEl.textContent = '✓ History cleared!';
                statusEl.classList.add('success');
                
                // রিসেট
                setTimeout(() => {
                    cleanBtn.disabled = false;
                    btnText.textContent = 'Clean Now';
                    statusEl.classList.remove('show', 'success');
                }, 1500);
            } else {
                // এরর
                statusEl.textContent = '✗ Failed to clear';
                statusEl.classList.add('error');
                
                setTimeout(() => {
                    cleanBtn.disabled = false;
                    btnText.textContent = 'Clean Now';
                    statusEl.classList.remove('show', 'error');
                }, 1500);
            }
        });
    });

    // হোভার ইফেক্ট
    cleanBtn.addEventListener('mouseenter', () => {
        if (!cleanBtn.disabled) {
            cleanBtn.style.transform = 'translateY(-1px)';
        }
    });

    cleanBtn.addEventListener('mouseleave', () => {
        cleanBtn.style.transform = 'translateY(0)';
    });
});