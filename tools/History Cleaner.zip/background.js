function clearAllHistory() {
    var since = 0;

    chrome.browsingData.remove({
        "since": since
    }, {
        "history": true
    });

    chrome.browsingData.remove({
        "since": since
    }, {
        "downloads": true
    });
}

chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
    if (request.action === "clear") {
        clearAllHistory();
        sendResponse({status: "success"});
    }
    return true;
});