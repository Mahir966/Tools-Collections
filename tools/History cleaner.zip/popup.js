document.addEventListener('DOMContentLoaded', function() {
    const cleanBtn = document.getElementById('clearHistoryBtn');
    const statusEl = document.getElementById('status');
    const btnText = cleanBtn.querySelector('.btn-text');

    cleanBtn.addEventListener('click', function() {
        cleanBtn.disabled = true;
        btnText.innerHTML = '<span class="spinner"></span> Cleaning...';
        
        statusEl.textContent = 'Clearing history...';
        statusEl.classList.add('show');

        chrome.runtime.sendMessage({action: "clear"}, function(response) {
            if (response && response.status === "success") {
                statusEl.textContent = '✓ History cleared!';
                statusEl.classList.add('success');
                
                setTimeout(() => {
                    cleanBtn.disabled = false;
                    btnText.textContent = 'Clean Now';
                    statusEl.classList.remove('show', 'success');
                }, 1500);
            } else {
                statusEl.textContent = '✗ Failed to clear';
                statusEl.classList.add('error');
                
                setTimeout(() => {
                    cleanBtn.disabled = false;
                    btnText.textContent = 'Clean Now';
                    statusEl.classList.remove('show', 'error');
                }, 1500);
            }
        });
    });

    cleanBtn.addEventListener('mouseenter', () => {
        if (!cleanBtn.disabled) {
            cleanBtn.style.transform = 'translateY(-1px)';
        }
    });

    cleanBtn.addEventListener('mouseleave', () => {
        cleanBtn.style.transform = 'translateY(0)';
    });
});